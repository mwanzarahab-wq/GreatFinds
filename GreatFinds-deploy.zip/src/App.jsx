import { Navigate, Route, Routes } from 'react-router-dom'
import AppShell from './components/AppShell.jsx'
import ErrorBoundary from './components/ErrorBoundary.jsx'
import Landing from './pages/Landing.jsx'
import Marketplace from './pages/Marketplace.jsx'
import ItemDetail from './pages/ItemDetail.jsx'
import StyleFeed from './pages/StyleFeed.jsx'
import Auth from './pages/Auth.jsx'

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Landing />} />

      <Route element={<AppShell />}>
        <Route
          path="/market"
          element={
            <ErrorBoundary>
              <Marketplace />
            </ErrorBoundary>
          }
        />
        <Route
          path="/market/:itemId"
          element={
            <ErrorBoundary>
              <ItemDetail />
            </ErrorBoundary>
          }
        />
        <Route
          path="/feed"
          element={
            <ErrorBoundary>
              <StyleFeed />
            </ErrorBoundary>
          }
        />
        <Route
          path="/account"
          element={
            <ErrorBoundary>
              <Auth />
            </ErrorBoundary>
          }
        />
      </Route>

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}
