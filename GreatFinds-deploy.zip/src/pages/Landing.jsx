import { Link } from 'react-router-dom'
import { Jacket, Sweater } from '../components/Garments.jsx'
import { Download, Hanger, Heart, Signal, WifiOff } from '../components/Icons.jsx'

const STEPS = [
  {
    title: 'Pick a listing',
    text: 'Open any active listing to see the current price and whether the auction is still live. The price updates on screen while you watch.'
  },
  {
    title: 'Place a higher bid',
    text: 'Enter an amount above the current price. A bid at or below it is turned down before it is sent.'
  },
  {
    title: 'Wait for confirmation',
    text: 'You only see a success message after the server accepts your bid, so the price on your screen never rolls back.'
  }
]

const FACTS = [
  {
    Icon: Download,
    title: 'Installs like an app',
    text: 'Add Great Finds to your home screen from your browser. There is no app store step.'
  },
  {
    Icon: Signal,
    title: 'Easy on your data',
    text: 'Listing photos are saved on your phone after the first load, so they are not downloaded again.'
  },
  {
    Icon: WifiOff,
    title: 'Pauses bidding when you are offline',
    text: 'A banner tells you when the connection drops, and the bid button stays off until you are back. Nothing is sent against an old price.'
  }
]

export default function Landing() {
  return (
    <div className="landing">
      <main>
        <section className="hero">
          <div className="container">
            <header className="landing-nav">
              <Link to="/" className="brand">
                <span className="brand-mark">
                  <Hanger />
                </span>
                <span className="brand-name">Great Finds</span>
              </Link>
              <nav className="landing-nav-links" aria-label="Main">
                <Link to="/market">Marketplace</Link>
                <Link to="/feed">Style Feed</Link>
                <Link to="/market" className="btn btn-primary btn-sm">
                  Open the app
                </Link>
              </nav>
            </header>

            <div className="hero-grid">
              <div className="hero-copy">
                <h1>Thrift fashion from Zambian stores, sold by auction</h1>
                <p className="lead">
                  Bid on secondhand pieces from local partner stores, or start from an outfit in
                  the style feed and go straight to the item.
                </p>
                <div className="hero-actions">
                  <Link to="/market" className="btn btn-primary">
                    Browse the marketplace
                  </Link>
                  <Link to="/feed" className="btn btn-soft">
                    Open the style feed
                  </Link>
                </div>
              </div>

              <div className="hero-visual" aria-hidden="true">
                <div className="mini-card mini-card--lime">
                  <span className="badge badge-live">Auction is live</span>
                  <Jacket className="mini-art" />
                  <span className="mini-label">Bid on thrifted pieces</span>
                </div>
                <div className="mini-card mini-card--pink">
                  <span className="mini-heart">
                    <Heart fill="currentColor" />
                  </span>
                  <Sweater className="mini-art" />
                  <span className="mini-label">Shop the look</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="section">
          <div className="container">
            <h2>Bid on a piece, or shop a look</h2>
            <p className="section-lead">
              Great Finds puts two ways of shopping secondhand fashion in one app.
            </p>
            <div className="pillars">
              <div className="pillar pillar--lime">
                <h3>Thrift Marketplace</h3>
                <p>
                  Browse thrifted pieces from local partner stores. Every listing is a live
                  auction, so you decide what you are willing to pay.
                </p>
                <Link to="/market" className="btn btn-primary">
                  Browse the marketplace
                </Link>
              </div>
              <div className="pillar pillar--pink">
                <h3>Style Feed</h3>
                <p>
                  A feed of curated outfit posts. Each post links to the item, so you can go from
                  a look you like to the piece itself.
                </p>
                <Link to="/feed" className="btn btn-primary">
                  Open the style feed
                </Link>
              </div>
            </div>
          </div>
        </section>

        <section className="section section--tint">
          <div className="container">
            <h2>How a bid works</h2>
            <p className="section-lead">Three steps from a listing to a confirmed bid.</p>
            <ol className="steps">
              {STEPS.map((step, i) => (
                <li key={step.title} className="step">
                  <span className="step-num">{i + 1}</span>
                  <div>
                    <h3>{step.title}</h3>
                    <p>{step.text}</p>
                  </div>
                </li>
              ))}
            </ol>
          </div>
        </section>

        <section className="section">
          <div className="container split">
            <div>
              <h2>Made for patchy connections</h2>
              <p className="section-lead">
                Great Finds is built for phones and the mobile data people actually have.
              </p>
            </div>
            <ul className="facts">
              {FACTS.map(({ Icon, title, text }) => (
                <li key={title} className="fact">
                  <span className="fact-icon">
                    <Icon />
                  </span>
                  <div>
                    <h3>{title}</h3>
                    <p>{text}</p>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </section>

        <section className="container cta-wrap">
          <div className="cta-band">
            <h2>See what is up for bidding</h2>
            <div className="cta-actions">
              <Link to="/market" className="btn btn-white">
                Browse the marketplace
              </Link>
              <Link to="/feed" className="btn btn-outline-white">
                Open the style feed
              </Link>
            </div>
          </div>
        </section>
      </main>

      <footer className="landing-footer">
        <div className="container footer-row">
          <Link to="/" className="brand">
            <span className="brand-mark">
              <Hanger />
            </span>
            <span className="brand-name">Great Finds</span>
          </Link>
          <nav className="footer-links" aria-label="Footer">
            <Link to="/market">Marketplace</Link>
            <Link to="/feed">Style Feed</Link>
          </nav>
          <p className="footer-note">© {new Date().getFullYear()} Great Finds</p>
        </div>
      </footer>
    </div>
  )
}
