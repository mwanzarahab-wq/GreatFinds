import { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { supabase } from '../lib/supabaseClient.js'
import { useAuctionStore } from '../store/useAuctionStore.js'
import LoadingSkeleton from '../components/LoadingSkeleton.jsx'
import { ChevronLeft } from '../components/Icons.jsx'

export default function ItemDetail() {
  const { itemId } = useParams()
  const [item, setItem] = useState(null)
  const [loadError, setLoadError] = useState(null)
  const [bidAmount, setBidAmount] = useState('')
  const [bidState, setBidState] = useState('idle')
  const [bidError, setBidError] = useState(null)
  const [isOffline, setIsOffline] = useState(!navigator.onLine)

  const liveSnapshot = useAuctionStore((state) => state.items[itemId])
  const subscribeToItem = useAuctionStore((state) => state.subscribeToItem)
  const unsubscribeFromItem = useAuctionStore((state) => state.unsubscribeFromItem)

  const currentPrice = liveSnapshot?.currentPrice ?? item?.current_price
  const status = liveSnapshot?.status ?? item?.status

  useEffect(() => {
    const fetchItem = async () => {
      setLoadError(null)
      const { data, error } = await supabase.from('items').select('*').eq('id', itemId).single()
      if (error) {
        setLoadError(error.message)
        return
      }
      setItem(data)
    }
    fetchItem()
  }, [itemId])

  useEffect(() => {
    subscribeToItem(itemId)
    return () => unsubscribeFromItem(itemId)
  }, [itemId, subscribeToItem, unsubscribeFromItem])

  useEffect(() => {
    const goOnline = () => setIsOffline(false)
    const goOffline = () => setIsOffline(true)
    window.addEventListener('online', goOnline)
    window.addEventListener('offline', goOffline)
    return () => {
      window.removeEventListener('online', goOnline)
      window.removeEventListener('offline', goOffline)
    }
  }, [])

  const handleBid = async (e) => {
    e.preventDefault()
    setBidError(null)

    const amount = Number(bidAmount)
    if (!amount || amount <= currentPrice) {
      setBidState('error')
      setBidError(`Your bid must be higher than the current price (ZMW ${currentPrice}).`)
      return
    }

    setBidState('submitting')

    const { error } = await supabase.rpc('place_bid', {
      p_item_id: itemId,
      p_bidder_id: (await supabase.auth.getUser()).data.user?.id,
      p_amount: amount
    })

    if (error) {
      setBidState('error')
      setBidError(error.message)
      return
    }

    setBidState('success')
    setBidAmount('')
  }

  if (loadError) {
    return (
      <div className="state-box">
        <p className="state-error">Couldn't load this item — {loadError}</p>
        <Link to="/market" className="btn btn-soft">
          Back to marketplace
        </Link>
      </div>
    )
  }

  if (!item) {
    return <LoadingSkeleton count={1} />
  }

  return (
    <div className="detail">
      <div className="detail-hero">
        <div className="detail-hero-inner">
          <Link to="/market" className="icon-btn" aria-label="Back to marketplace">
            <ChevronLeft />
          </Link>
          <img src={item.images?.[0]} alt={item.title} className="detail-img" />
        </div>
      </div>

      <div className="detail-sheet">
        <h1 className="detail-title">{item.title}</h1>
        <p className="detail-desc">{item.description}</p>

        <div className="price-row">
          <p className="detail-price">ZMW {currentPrice}</p>
          <span className={'badge ' + (status === 'active' ? 'badge-live' : 'badge-ended')}>
            {status === 'active' ? 'Auction is live' : 'Auction has ended'}
          </span>
        </div>

        {status === 'active' && (
          <form onSubmit={handleBid} className="bid-form">
            <label htmlFor="bid-amount" className="bid-label">
              Your bid (ZMW)
            </label>
            <input
              id="bid-amount"
              type="number"
              min={currentPrice + 1}
              value={bidAmount}
              onChange={(e) => setBidAmount(e.target.value)}
              disabled={bidState === 'submitting' || isOffline}
              className="bid-input"
            />

            <button
              type="submit"
              disabled={bidState === 'submitting' || isOffline}
              className="btn btn-primary btn-block"
            >
              {isOffline
                ? "You're offline"
                : bidState === 'submitting'
                ? 'Placing bid…'
                : 'Place bid'}
            </button>

            {bidState === 'error' && (
              <p role="alert" className="bid-msg bid-msg--error">
                {bidError}
              </p>
            )}
            {bidState === 'success' && (
              <p role="status" className="bid-msg bid-msg--ok">
                Bid placed — you're currently the highest bidder.
              </p>
            )}
          </form>
        )}
      </div>
    </div>
  )
}
