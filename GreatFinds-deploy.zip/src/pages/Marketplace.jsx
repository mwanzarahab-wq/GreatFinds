import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../lib/supabaseClient.js'
import LoadingSkeleton from '../components/LoadingSkeleton.jsx'

export default function Marketplace() {
  const [items, setItems] = useState(null)
  const [error, setError] = useState(null)

  const fetchItems = async () => {
    setError(null)
    setItems(null)

    const { data, error: fetchError } = await supabase
      .from('items')
      .select('id, title, images, current_price, status, ends_at')
      .eq('status', 'active')
      .order('created_at', { ascending: false })

    if (fetchError) {
      setError(fetchError.message)
      return
    }
    setItems(data)
  }

  useEffect(() => {
    fetchItems()
  }, [])

  if (error) {
    return (
      <div className="state-box">
        <p className="state-error">Couldn't load listings — {error}</p>
        <button onClick={fetchItems} className="btn btn-primary">
          Retry
        </button>
      </div>
    )
  }

  if (items === null) {
    return <LoadingSkeleton />
  }

  if (items.length === 0) {
    return (
      <div className="state-box">
        <p className="state-title">No active listings yet.</p>
        <p className="state-text">Check back soon, or be the first to list something.</p>
      </div>
    )
  }

  return (
    <div className="card-grid">
      {items.map((item) => (
        <Link key={item.id} to={`/market/${item.id}`} className="product-card">
          <img
            src={item.images?.[0]}
            alt={item.title}
            loading="lazy"
            className="product-img"
          />
          <div className="product-meta">
            <p className="product-title">{item.title}</p>
            <p className="product-price">ZMW {item.current_price}</p>
          </div>
        </Link>
      ))}
    </div>
  )
}
