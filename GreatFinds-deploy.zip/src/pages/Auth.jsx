import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../lib/supabaseClient.js'

export default function Auth() {
  const [session, setSession] = useState(null)
  const [mode, setMode] = useState('signin')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [busy, setBusy] = useState(false)
  const [msg, setMsg] = useState(null)

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setSession(data.session))
    const { data } = supabase.auth.onAuthStateChange((_event, s) => setSession(s))
    return () => data.subscription.unsubscribe()
  }, [])

  const handleSubmit = async (e) => {
    e.preventDefault()
    setBusy(true)
    setMsg(null)
    const { data, error } =
      mode === 'signin'
        ? await supabase.auth.signInWithPassword({ email, password })
        : await supabase.auth.signUp({ email, password })
    setBusy(false)
    if (error) {
      setMsg({ type: 'error', text: error.message })
    } else if (mode === 'signup' && !data.session) {
      setMsg({ type: 'ok', text: 'Check your email to confirm your account, then sign in.' })
    }
  }

  if (session) {
    return (
      <div className="auth">
        <p className="state-title">You're signed in</p>
        <p className="state-text">{session.user.email}</p>
        <div className="two">
          <Link to="/market" className="btn btn-soft">
            Browse listings
          </Link>
          <button className="btn btn-primary" onClick={() => supabase.auth.signOut()}>
            Sign out
          </button>
        </div>
      </div>
    )
  }

  return (
    <form onSubmit={handleSubmit} className="auth bid-form">
      <label htmlFor="email" className="bid-label">
        Email
      </label>
      <input
        id="email"
        type="email"
        required
        autoComplete="email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        className="bid-input"
      />
      <label htmlFor="password" className="bid-label">
        Password
      </label>
      <input
        id="password"
        type="password"
        required
        minLength={6}
        autoComplete={mode === 'signin' ? 'current-password' : 'new-password'}
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        className="bid-input"
      />
      <button type="submit" disabled={busy} className="btn btn-primary btn-block">
        {busy ? 'Please wait…' : mode === 'signin' ? 'Sign in' : 'Create account'}
      </button>
      {msg && (
        <p role={msg.type === 'error' ? 'alert' : 'status'} className={'bid-msg bid-msg--' + (msg.type === 'error' ? 'error' : 'ok')}>
          {msg.text}
        </p>
      )}
      <button
        type="button"
        className="btn btn-soft btn-block"
        onClick={() => {
          setMode(mode === 'signin' ? 'signup' : 'signin')
          setMsg(null)
        }}
      >
        {mode === 'signin' ? 'New here? Create an account' : 'Have an account? Sign in'}
      </button>
    </form>
  )
}
