import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../lib/supabaseClient.js'
import LoadingSkeleton from '../components/LoadingSkeleton.jsx'

export default function StyleFeed() {
  const [posts, setPosts] = useState(null)
  const [error, setError] = useState(null)

  const fetchPosts = async () => {
    setError(null)
    setPosts(null)

    const { data, error: fetchError } = await supabase
      .from('style_feed_posts')
      .select('id, images, caption, linked_item_id, likes_count')
      .order('created_at', { ascending: false })

    if (fetchError) {
      setError(fetchError.message)
      return
    }
    setPosts(data)
  }

  useEffect(() => {
    fetchPosts()
  }, [])

  if (error) {
    return (
      <div className="state-box">
        <p className="state-error">Couldn't load the feed — {error}</p>
        <button onClick={fetchPosts} className="btn btn-primary">
          Retry
        </button>
      </div>
    )
  }

  if (posts === null) {
    return <LoadingSkeleton />
  }

  if (posts.length === 0) {
    return (
      <div className="state-box">
        <p className="state-title">No style posts yet.</p>
        <p className="state-text">Be the first to share a look.</p>
      </div>
    )
  }

  return (
    <div className="card-grid card-grid--feed">
      {posts.map((post) => (
        <article key={post.id} className="feed-card">
          <img
            src={post.images?.[0]}
            alt={post.caption || 'Style feed post'}
            loading="lazy"
            className="feed-img"
          />
          <div className="feed-meta">
            <p className="feed-caption">{post.caption}</p>
            {post.linked_item_id && (
              <Link to={`/market/${post.linked_item_id}`} className="feed-link">
                Shop this look →
              </Link>
            )}
          </div>
        </article>
      ))}
    </div>
  )
}
