import React from 'react'

export default class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props)
    this.state = { hasError: false }
  }

  static getDerivedStateFromError() {
    return { hasError: true }
  }

  componentDidCatch(error, info) {
    console.error('Great Finds — caught render error:', error, info)
  }

  handleRetry = () => {
    this.setState({ hasError: false })
  }

  render() {
    if (this.state.hasError) {
      return (
        <div role="alert" className="state-box">
          <p className="state-title">Something didn't load right.</p>
          <p className="state-text">Nothing was lost — try again.</p>
          <button onClick={this.handleRetry} className="btn btn-primary">
            Retry
          </button>
        </div>
      )
    }

    return this.props.children
  }
}
