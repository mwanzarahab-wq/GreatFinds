function Icon({ size = 22, fill = 'none', children }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill={fill}
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      focusable="false"
    >
      {children}
    </svg>
  )
}

export const Hanger = (p) => (
  <Icon {...p}>
    <path d="M12 8.5a2.3 2.3 0 1 0-2.3-2.3" />
    <path d="M12 8.5v1.7L3.6 16.2a1.4 1.4 0 0 0 .8 2.5h15.2a1.4 1.4 0 0 0 .8-2.5L12 10.2" />
  </Icon>
)

export const Home = (p) => (
  <Icon {...p}>
    <path d="M3 11.5 12 4l9 7.5" />
    <path d="M5.5 10v9.5h13V10" />
  </Icon>
)

export const Bag = (p) => (
  <Icon {...p}>
    <path d="M5 8h14l-1 12H6L5 8Z" />
    <path d="M9 8V7a3 3 0 0 1 6 0v1" />
  </Icon>
)

export const Photos = (p) => (
  <Icon {...p}>
    <rect x="4" y="4" width="16" height="16" rx="4" />
    <circle cx="9" cy="10" r="1.6" />
    <path d="m5 17 4.5-4.5 3 3 2.5-2.5L19 17" />
  </Icon>
)

export const Heart = (p) => (
  <Icon {...p}>
    <path d="M12 20s-7.5-4.6-7.5-10.2A4.3 4.3 0 0 1 12 7.4a4.3 4.3 0 0 1 7.5 2.4C19.5 15.4 12 20 12 20Z" />
  </Icon>
)

export const ChevronLeft = (p) => (
  <Icon {...p}>
    <path d="m15 5-7 7 7 7" />
  </Icon>
)

export const Download = (p) => (
  <Icon {...p}>
    <path d="M12 4v11" />
    <path d="m7.5 10.5 4.5 4.5 4.5-4.5" />
    <path d="M5 20h14" />
  </Icon>
)

export const Signal = (p) => (
  <Icon {...p}>
    <path d="M5 19v-3M10 19v-7M15 19V8M20 19V4" />
  </Icon>
)

export const WifiOff = (p) => (
  <Icon {...p}>
    <path d="M2 8.8a15 15 0 0 1 20 0" />
    <path d="M5.5 12.4a10 10 0 0 1 13 0" />
    <path d="M9 16a5 5 0 0 1 6 0" />
    <path d="M12 19.5h.01" />
    <path d="M3 3l18 18" />
  </Icon>
)

export const User = (p) => (
  <Icon {...p}>
    <circle cx="12" cy="8.5" r="3.5" />
    <path d="M5 20a7 7 0 0 1 14 0" />
  </Icon>
)
