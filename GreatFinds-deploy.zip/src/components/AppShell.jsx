import { Link, NavLink, Outlet, useLocation } from 'react-router-dom'
import OfflineBanner from './OfflineBanner.jsx'
import { Bag, Hanger, Home, Photos, User } from './Icons.jsx'

const HEADINGS = {
  '/market': { title: 'Marketplace', sub: 'Live auctions from partner stores' },
  '/feed': { title: 'Style Feed', sub: 'Outfits you can shop' },
  '/account': { title: 'Account', sub: 'Sign in to place bids' }
}

const navClass = ({ isActive }) => 'nav-item' + (isActive ? ' active' : '')

export default function AppShell() {
  const { pathname } = useLocation()
  const heading = HEADINGS[pathname.replace(/\/+$/, '')]

  return (
    <div className="shell">
      <OfflineBanner />

      {heading && (
        <header className="app-header">
          <div className="app-header-inner">
            <Link to="/" className="brand-mark" aria-label="Great Finds home">
              <Hanger />
            </Link>
            <div>
              <h1 className="page-title">{heading.title}</h1>
              <p className="page-sub">{heading.sub}</p>
            </div>
          </div>
        </header>
      )}

      <main>
        <Outlet />
      </main>

      <nav className="bottom-nav" aria-label="Primary">
        <NavLink to="/" end className={navClass}>
          <Home />
          <span className="nav-label">Home</span>
        </NavLink>
        <NavLink to="/market" className={navClass}>
          <Bag />
          <span className="nav-label">Market</span>
        </NavLink>
        <NavLink to="/feed" className={navClass}>
          <Photos />
          <span className="nav-label">Feed</span>
        </NavLink>
        <NavLink to="/account" className={navClass}>
          <User />
          <span className="nav-label">Account</span>
        </NavLink>
      </nav>
    </div>
  )
}
