// Flat garment illustrations used on the landing page.

export function Sweater({ className }) {
  return (
    <svg className={className} viewBox="0 0 200 200" aria-hidden="true" focusable="false">
      <path
        d="M70 26 L28 46 L10 118 L40 126 L52 96 L52 176 L148 176 L148 96 L160 126 L190 118 L172 46 L130 26 Q100 52 70 26 Z"
        fill="#F2B3C2"
        stroke="#F2B3C2"
        strokeWidth="6"
        strokeLinejoin="round"
      />
      <path d="M70 26 Q100 52 130 26" fill="none" stroke="#DE8EA4" strokeWidth="9" strokeLinecap="round" />
      <rect x="52" y="164" width="96" height="12" rx="4" fill="#E9A0B3" />
      <path d="M12 112 L42 120" stroke="#E9A0B3" strokeWidth="9" strokeLinecap="round" />
      <path d="M188 112 L158 120" stroke="#E9A0B3" strokeWidth="9" strokeLinecap="round" />
      <path d="M52 100 V164 M148 100 V164" stroke="#E9A0B3" strokeWidth="2" opacity="0.6" />
    </svg>
  )
}

export function Jacket({ className }) {
  return (
    <svg className={className} viewBox="0 0 200 200" aria-hidden="true" focusable="false">
      <path
        d="M70 26 L28 46 L10 118 L40 126 L52 96 L52 176 L148 176 L148 96 L160 126 L190 118 L172 46 L130 26 Q100 52 70 26 Z"
        fill="#566244"
        stroke="#566244"
        strokeWidth="6"
        strokeLinejoin="round"
      />
      <path d="M84 32 Q100 56 116 32 L114 176 L86 176 Z" fill="#FFFFFF" />
      <path d="M86 40 V176 M114 40 V176" stroke="#434D35" strokeWidth="2" />
      <path d="M70 26 L92 28 L98 54 L78 44 Z" fill="#434D35" />
      <path d="M130 26 L108 28 L102 54 L122 44 Z" fill="#434D35" />
      <rect x="58" y="110" width="22" height="24" rx="3" fill="none" stroke="#434D35" strokeWidth="2" />
      <rect x="120" y="110" width="22" height="24" rx="3" fill="none" stroke="#434D35" strokeWidth="2" />
      <path d="M12 112 L42 120" stroke="#434D35" strokeWidth="8" strokeLinecap="round" />
      <path d="M188 112 L158 120" stroke="#434D35" strokeWidth="8" strokeLinecap="round" />
    </svg>
  )
}
