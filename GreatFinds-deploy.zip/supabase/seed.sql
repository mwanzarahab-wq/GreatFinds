-- Demo data. Pictures are the stand-in images in public/images.
insert into public.partner_stores (id, name, city) values
  ('b0000000-0000-0000-0000-000000000001', 'Demo Store One', 'Lusaka'),
  ('b0000000-0000-0000-0000-000000000002', 'Demo Store Two', 'Kitwe')
on conflict (id) do nothing;

insert into public.items (id, store_id, title, description, images, category, starting_price, current_price, ends_at) values
  ('a0000000-0000-0000-0000-000000000001','b0000000-0000-0000-0000-000000000001','Knit sweater','Soft pink knit, relaxed fit.','{/images/item-1.jpg}','Knitwear',80,80, now() + interval '3 days'),
  ('a0000000-0000-0000-0000-000000000002','b0000000-0000-0000-0000-000000000001','Green shirt jacket','Heavy cotton overshirt with two chest pockets.','{/images/item-2.jpg}','Jackets',150,150, now() + interval '4 days'),
  ('a0000000-0000-0000-0000-000000000003','b0000000-0000-0000-0000-000000000002','Cream cardigan','Button front, light wool blend.','{/images/item-3.jpg}','Knitwear',95,95, now() + interval '2 days'),
  ('a0000000-0000-0000-0000-000000000004','b0000000-0000-0000-0000-000000000002','Denim jacket','Washed denim, slightly cropped.','{/images/item-4.jpg}','Jackets',210,210, now() + interval '5 days'),
  ('a0000000-0000-0000-0000-000000000005','b0000000-0000-0000-0000-000000000001','Rust sweater','Chunky knit, crew neck.','{/images/item-5.jpg}','Knitwear',70,70, now() + interval '3 days'),
  ('a0000000-0000-0000-0000-000000000006','b0000000-0000-0000-0000-000000000002','Lilac top','Lightweight long sleeve.','{/images/item-6.jpg}','Tops',55,55, now() + interval '6 days')
on conflict (id) do nothing;

insert into public.style_feed_posts (id, images, caption, linked_item_id, likes_count) values
  ('c0000000-0000-0000-0000-000000000001','{/images/post-1.jpg}','Weekend layers, one knit and one overshirt.','a0000000-0000-0000-0000-000000000002',0),
  ('c0000000-0000-0000-0000-000000000002','{/images/post-2.jpg}','Soft pinks for a warm afternoon.','a0000000-0000-0000-0000-000000000001',0),
  ('c0000000-0000-0000-0000-000000000003','{/images/post-3.jpg}','Denim over cream, easy and clean.','a0000000-0000-0000-0000-000000000004',0),
  ('c0000000-0000-0000-0000-000000000004','{/images/post-4.jpg}','Rust and green for the rainy season.','a0000000-0000-0000-0000-000000000005',0)
on conflict (id) do nothing;
