# Backend setup

1. Create a project at supabase.com.
2. SQL Editor: run `schema.sql`, then `seed.sql`.
3. Project Settings > API: copy the project URL and anon key into `.env` (see `.env.example`) and into Netlify's environment variables.
4. Authentication > Providers: keep Email on. Turn off "Confirm email" while testing if you want to sign in straight away.
5. `npm install && npm run dev`, open Account, create an account, then place a bid.

Items cannot be edited from the app. Add or change listings in the Table Editor. To use real photos, upload them to the `item-images` bucket and put the public URL in `items.images`.
