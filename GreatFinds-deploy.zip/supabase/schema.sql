-- Great Finds: database schema for Supabase (Postgres, Auth, Realtime, Storage)
-- Run this whole file once in the Supabase SQL Editor, then run seed.sql.

create table if not exists public.partner_stores (
  id         uuid primary key default gen_random_uuid(),
  name       text not null unique,
  city       text,
  created_at timestamptz not null default now()
);

create table if not exists public.items (
  id                uuid primary key default gen_random_uuid(),
  store_id          uuid references public.partner_stores(id) on delete set null,
  title             text not null,
  description       text not null default '',
  images            text[] not null default '{}',
  category          text,
  starting_price    numeric(10,2) not null check (starting_price >= 0),
  current_price     numeric(10,2) not null check (current_price >= 0),
  highest_bidder_id uuid references auth.users(id) on delete set null,
  status            text not null default 'active' check (status in ('active', 'ended')),
  ends_at           timestamptz not null,
  created_at        timestamptz not null default now()
);
create index if not exists items_status_created_idx on public.items (status, created_at desc);

create table if not exists public.bids (
  id         uuid primary key default gen_random_uuid(),
  item_id    uuid not null references public.items(id) on delete cascade,
  bidder_id  uuid not null references auth.users(id) on delete cascade,
  amount     numeric(10,2) not null check (amount > 0),
  created_at timestamptz not null default now()
);
create index if not exists bids_item_amount_idx on public.bids (item_id, amount desc);

create table if not exists public.style_feed_posts (
  id             uuid primary key default gen_random_uuid(),
  images         text[] not null default '{}',
  caption        text not null default '',
  linked_item_id uuid references public.items(id) on delete set null,
  likes_count    integer not null default 0,
  created_at     timestamptz not null default now()
);
create index if not exists feed_created_idx on public.style_feed_posts (created_at desc);

-- Row level security: the public can read listings and the feed.
-- Nobody writes to items or bids directly. Bids go through place_bid() below.
alter table public.partner_stores   enable row level security;
alter table public.items            enable row level security;
alter table public.bids             enable row level security;
alter table public.style_feed_posts enable row level security;

drop policy if exists "stores are public"  on public.partner_stores;
drop policy if exists "items are public"   on public.items;
drop policy if exists "feed is public"     on public.style_feed_posts;
drop policy if exists "see your own bids"  on public.bids;

create policy "stores are public" on public.partner_stores   for select using (true);
create policy "items are public"  on public.items            for select using (true);
create policy "feed is public"    on public.style_feed_posts for select using (true);
create policy "see your own bids" on public.bids             for select to authenticated using (bidder_id = auth.uid());

-- place_bid: the only way to bid. The row is locked while it is checked, so two
-- bidders cannot both win the same price. The app calls it with named arguments.
create or replace function public.place_bid(
  p_item_id   uuid,
  p_bidder_id uuid    default null,
  p_amount    numeric default null
) returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_item public.items%rowtype;
begin
  if auth.uid() is null or p_bidder_id is null then
    raise exception 'Sign in to place a bid.';
  end if;
  if p_bidder_id <> auth.uid() then
    raise exception 'The bidder does not match the signed-in account.';
  end if;
  if p_amount is null or p_amount <= 0 then
    raise exception 'Enter a bid amount.';
  end if;

  select * into v_item from public.items where id = p_item_id for update;
  if not found then
    raise exception 'This item does not exist.';
  end if;
  if v_item.status <> 'active' or v_item.ends_at <= now() then
    raise exception 'This auction has ended.';
  end if;
  if p_amount <= v_item.current_price then
    raise exception 'Your bid must be higher than the current price (ZMW %).', v_item.current_price;
  end if;

  insert into public.bids (item_id, bidder_id, amount) values (p_item_id, auth.uid(), p_amount);
  update public.items
     set current_price = p_amount, highest_bidder_id = auth.uid()
   where id = p_item_id;
end;
$$;

revoke all on function public.place_bid(uuid, uuid, numeric) from public, anon;
grant execute on function public.place_bid(uuid, uuid, numeric) to authenticated;

-- Marks auctions whose time is up as ended.
create or replace function public.end_expired_auctions() returns integer
language sql security definer set search_path = public as $$
  with done as (
    update public.items set status = 'ended'
     where status = 'active' and ends_at <= now()
    returning 1
  ) select count(*)::integer from done;
$$;
revoke all on function public.end_expired_auctions() from public, anon, authenticated;
-- To run it every minute, enable the pg_cron extension (Database > Extensions), then:
--   select cron.schedule('end-auctions', '* * * * *', 'select public.end_expired_auctions()');

-- Live price updates: the app listens for changes to items.
do $$ begin
  alter publication supabase_realtime add table public.items;
exception when duplicate_object then null; end $$;

-- Storage bucket for real listing photos (public read).
insert into storage.buckets (id, name, public)
values ('item-images', 'item-images', true)
on conflict (id) do nothing;
